var pixelix_8h =
[
    [ "pixelix", "classpixelix.html", "classpixelix" ],
    [ "PIXELIX_H", "pixelix_8h.html#a71a9a6012772f6d78bff0190d1e64e6c", null ]
];