var files_dup =
[
    [ "Pixelit", "dir_cc9bbb150eae8bb47a72fc72f1da5add.html", "dir_cc9bbb150eae8bb47a72fc72f1da5add" ]
];