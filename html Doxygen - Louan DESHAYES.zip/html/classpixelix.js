var classpixelix =
[
    [ "pixelix", "classpixelix.html#a437119029a6ad66bea98efda45a63d59", null ],
    [ "envoyer_trame", "classpixelix.html#ab5d9945b6a82b4746fa2457d94b9c2b5", null ],
    [ "envoyer_txt", "classpixelix.html#acea7d35c637cd98ac746a2103c12a7d7", null ],
    [ "get", "classpixelix.html#aefbfcfc6dabc456605b218559b7b1b24", null ],
    [ "get_brightness", "classpixelix.html#abfa49886b890d19d7714ec0285ed9954", null ],
    [ "get_json_brightness", "classpixelix.html#a2e137faf25a8eec79a4efdbb5be055e3", null ],
    [ "post", "classpixelix.html#aa433a23137db8b2db43c5402d52d1a46", null ],
    [ "set_url", "classpixelix.html#a195b69d622526f8c77450a9a6f0c6dac", null ],
    [ "text", "classpixelix.html#a7164e75135834f89e415293e9a2b66c9", null ],
    [ "Trame", "classpixelix.html#a669c1a1b89a535c580268edd4f44537b", null ],
    [ "jsontext", "classpixelix.html#aaa9d4e8193661d595ea17fbdeab9e142", null ],
    [ "jsontrame", "classpixelix.html#a623b6a42ad3ac9053c52f11e5ebe66d5", null ],
    [ "m", "classpixelix.html#adbfbecbb104df4cc008f8df8402c4dc0", null ],
    [ "qurl", "classpixelix.html#a8891280320f7d2179d3ea78d638cc3ef", null ]
];