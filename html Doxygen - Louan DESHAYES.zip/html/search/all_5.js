var searchData=
[
  ['jsontext_0',['jsontext',['../classpixelix.html#aaa9d4e8193661d595ea17fbdeab9e142',1,'pixelix']]],
  ['jsontrame_1',['jsontrame',['../classpixelix.html#a623b6a42ad3ac9053c52f11e5ebe66d5',1,'pixelix']]]
];
