var searchData=
[
  ['envoyer_5ftrame_0',['envoyer_Trame',['../classfenetre.html#ac8465205e775f415b0c631381f0de39e',1,'fenetre']]],
  ['envoyer_5ftrame_1',['envoyer_trame',['../classpixelix.html#ab5d9945b6a82b4746fa2457d94b9c2b5',1,'pixelix']]],
  ['envoyer_5ftxt_2',['envoyer_txt',['../classfenetre.html#a91340de74e641f9728d014e18a62bf0f',1,'fenetre::envoyer_txt()'],['../classpixelix.html#acea7d35c637cd98ac746a2103c12a7d7',1,'pixelix::envoyer_txt()']]]
];
