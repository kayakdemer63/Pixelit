var indexSectionsWithContent =
{
  0: "acefgjlmpqstu~",
  1: "fp",
  2: "u",
  3: "fmp",
  4: "cefgmpst~",
  5: "acejmqu",
  6: "fp",
  7: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Espaces de nommage",
  3: "Fichiers",
  4: "Fonctions",
  5: "Variables",
  6: "Macros",
  7: "Pages"
};

