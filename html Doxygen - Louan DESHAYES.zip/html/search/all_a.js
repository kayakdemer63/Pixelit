var searchData=
[
  ['set_5furl_0',['set_url',['../classpixelix.html#a195b69d622526f8c77450a9a6f0c6dac',1,'pixelix']]]
];
