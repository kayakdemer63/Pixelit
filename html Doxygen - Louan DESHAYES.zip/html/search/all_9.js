var searchData=
[
  ['qurl_0',['qurl',['../classpixelix.html#a8891280320f7d2179d3ea78d638cc3ef',1,'pixelix']]]
];
