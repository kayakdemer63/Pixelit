var searchData=
[
  ['pixelix_2ecpp_0',['pixelix.cpp',['../pixelix_8cpp.html',1,'']]],
  ['pixelix_2eh_1',['pixelix.h',['../pixelix_8h.html',1,'']]]
];
