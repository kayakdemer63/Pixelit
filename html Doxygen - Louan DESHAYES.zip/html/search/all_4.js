var searchData=
[
  ['get_0',['get',['../classpixelix.html#aefbfcfc6dabc456605b218559b7b1b24',1,'pixelix']]],
  ['get_5fbrightness_1',['get_brightness',['../classpixelix.html#abfa49886b890d19d7714ec0285ed9954',1,'pixelix']]],
  ['get_5fjson_5fbrightness_2',['get_json_brightness',['../classpixelix.html#a2e137faf25a8eec79a4efdbb5be055e3',1,'pixelix']]]
];
