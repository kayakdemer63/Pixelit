var annotated_dup =
[
    [ "fenetre", "classfenetre.html", "classfenetre" ],
    [ "pixelix", "classpixelix.html", "classpixelix" ]
];